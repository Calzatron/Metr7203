/*
 * plant_block_types.h
 *
 * Code generation for model "plant_block".
 *
 * Model version              : 1.147
 * Simulink Coder version : 8.4 (R2013a) 13-Feb-2013
 * C source code generated on : Wed Aug 30 09:38:31 2017
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_plant_block_types_h_
#define RTW_HEADER_plant_block_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_plant_block_T_ P_plant_block_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_plant_block_T RT_MODEL_plant_block_T;

#endif                                 /* RTW_HEADER_plant_block_types_h_ */
