/*
 * State_Flow_v0_types.h
 *
 * Code generation for model "State_Flow_v0".
 *
 * Model version              : 1.35
 * Simulink Coder version : 8.4 (R2013a) 13-Feb-2013
 * C source code generated on : Mon Sep 11 08:59:18 2017
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Specified
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_State_Flow_v0_types_h_
#define RTW_HEADER_State_Flow_v0_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_ P;

#endif                                 /* RTW_HEADER_State_Flow_v0_types_h_ */
